# SAP ABAP CI/CD Demo with GitLab

이 프로젝트는 SAP ABAP 프로그램을 GitLab CI/CD 파이프라인으로 관리하는 예시입니다.
CI/CD 자동화는 개발 → 테스트 → 배포 과정을 효율적으로 처리할 수 있도록 도와줍니다.

## 구성 파일
- abap/ZDEMO_PROGRAM.abap: 샘플 ABAP 프로그램
- .gitlab-ci.yml: GitLab 파이프라인 설정 파일
